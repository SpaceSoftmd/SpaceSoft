package HotelChain.Interfaces;

public interface Menu {
    void realizeMenu();

    void displayMenuList();

    boolean realizeChoice(int choice);

    int readChoice();
}
