package HotelChain;

public class Main {
    public static void main(String[] args) {
        HotelChain hotelChain = new HotelChain();
        hotelChain.realizeMenu();
    }
}
