package CompanieDeConsultatii;

public interface Menu {
    void afiseazaLista();

    void apeleazaMenu();
}
