package CompanieDeConsultatii;

public class Main {
    public static void main(String[] args) {
        Companie companie = new Companie();
        companie.apeleazaMenu();
    }
}
